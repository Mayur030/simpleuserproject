import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormComponent } from '../form/form.component';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { environment } from 'src/environment/environment';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent {

  productArray: any = [];
  displayedColumns: string[] = [
    'name',
    'email',
    'rollno',
  ];
  dataSource = new MatTableDataSource([]);

  constructor(private dialog: MatDialog) {}

  ngOnInit(): void {
    this.GetProduct();
  }

  GetProduct() {
    this.productArray = localStorage.getItem(environment.key);
    if (this.productArray) {
      this.productArray = JSON.parse(this.productArray);
      this.dataSource = this.productArray;
    }
  }

  AddProduct() {
    this.dialog
      .open(FormComponent, { width: '45%', height: '80%' })
      .afterClosed()
      .subscribe((res) => {
        if (res) {
        this.GetProduct();
        }
      });
  }

  editProduct(id: any) {
      let data = { id };
      this.dialog
        .open(FormComponent, { data, width: '45%', height: '80%' })
        .afterClosed()
        .subscribe((res) => {
          if (res) {
          this.GetProduct();
          }
        });
  }

  DeleteProduct(id: any) {
    let index = this.productArray.findIndex((x: any) => x.id == id);
    this.productArray.splice(index, 1);
    localStorage.setItem(environment.key, JSON.stringify(this.productArray));
    this.GetProduct();
  }
}
