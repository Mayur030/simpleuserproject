import { Component, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { environment } from 'src/environment/environment';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
})
export class FormComponent {
  productForms: FormGroup | any;

  productArray: any = [];
  dataSource: any = [];

  constructor(
    private formBuilder: FormBuilder,
    private MatdialogRef: MatDialogRef<Component>,

    @Inject(MAT_DIALOG_DATA) public productData: any
  ) {}

  ngOnInit(): void {
    this.productArray = localStorage.getItem(environment.key);
    if (this.productArray) {
      this.dataSource = JSON.parse(this.productArray);
    }

    this.productForms = this.formBuilder.group({
      name: [''],
      Email: [''],
      rollNo: [''],
    });

    if (this.productData && this.productData.id) {
      this.dataSource.forEach((element: any) => {
        if (element.id === this.productData.id) {
          this.productForms.patchValue({
            name: element.name,
            email: element.email,
            rollNo: element.rollNo,
          });
        }
      });
    }
  }

  SubmitForm() {
    if (this.productForms.valid) {
      if (this.productForms.value.id) {
        let index = '';
        index = this.dataSource.findIndex(
          (x: any) => x.id == this.productForms.value.id
        );
        this.dataSource.splice(index, 1, this.productForms.value);
      } else {
        this.productForms.patchValue({
          id: new Date().getTime(),
        });
        this.dataSource.push(this.productForms.value);
      }
      localStorage.setItem(environment.key, JSON.stringify(this.dataSource));
      this.productForms.reset();
      this.closeDialog(true);
    }
  }

  closeDialog(event: any) {
    this.MatdialogRef.close(event);
  }
}
