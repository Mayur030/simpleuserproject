export const environment = {
    key : 'sfghjkfgh'
}